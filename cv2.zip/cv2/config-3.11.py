PYTHON_EXTENSIONS_PATHS = [
    os.path.join('C:/workspace/vims/venv/Lib/site-packages/cv2', 'python-3.11')
] + PYTHON_EXTENSIONS_PATHS
