import os

BINARIES_PATHS = [
    os.path.join('C:/workspace/opencv/build/install', 'x64/vc17/bin')
] + BINARIES_PATHS
